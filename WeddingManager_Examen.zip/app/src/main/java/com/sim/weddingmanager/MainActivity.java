package com.sim.weddingmanager;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {

	public static final String PREF_NAME = "EspritMobilePrefs";
	
	Button button_valider;
	EditText ed_name, ed_date;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		/** TRAP 1 **/
		
		button_valider.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {

				/** TODO1 SharedPrefs**/
				
				/** TODO2 Intent**/
				
			}
		});
		
	}

	
}
