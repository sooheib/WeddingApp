package com.sim.weddingmanager;

import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.widget.ListView;

public class EventListActivity extends Activity{

	HashMap<String, String> map;
	ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String,String>>();
	
	String[] hotel_names;
	String[] hotel_prices;
	TypedArray hotel_images;
	
	String[] car_names;
	String[] car_prices;
	TypedArray car_images;
	
	String[] deco_names;
	String[] deco_prices;
	TypedArray deco_images;
	
	String[] cake_names;
	String[] cake_prices;
	TypedArray cake_images;
	
	ListView listView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		/** TRAP 2 **/
		
		hotel_names = getResources().getStringArray(R.array.hotel_name);
		hotel_prices = getResources().getStringArray(R.array.hotel_price);
		hotel_images = getResources().obtainTypedArray(R.array.hotel_image);
		
		car_names = getResources().getStringArray(R.array.car_name);
		car_prices = getResources().getStringArray(R.array.car_price);
		car_images = getResources().obtainTypedArray(R.array.car_image);
		
		cake_names = getResources().getStringArray(R.array.cake_name);
		cake_prices = getResources().getStringArray(R.array.cake_price);
		cake_images = getResources().obtainTypedArray(R.array.cake_image);
		
		deco_names = getResources().getStringArray(R.array.deco_name);
		deco_prices = getResources().getStringArray(R.array.deco_price);
		deco_images = getResources().obtainTypedArray(R.array.deco_image);
		
		/** HINT GET IMAGE RESSOURCE 
		 * FROM TYPEDARRAY :
		 * String.valueOf(deco_images.getResourceId(i, -1)) **/
		
		
		/** TODO 8 GET INTENT + FEEDING THE ArrayList **/
		
		/** TODO 9 SIMPLE ADAPTER **/
		
		/** TODO 10 OnItemClickListener + INSERT DATABASE + RESULT -> DASHBOARD_ACTIVITY **/
		
		
	}

}
