package com.sim.weddingmanager;

import android.app.Activity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.ViewGroup.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;

public class DashboardActivity extends Activity {

	TextView tv_name;
	ImageButton img_hotel, img_cake, img_car, img_deco;
	private static final int CONTENT_VIEW_ID = 10101010;
	boolean fragmentOpened = false;
	Bundle savedInstanceState;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_dashboard);

		img_cake = (ImageButton) findViewById(R.id.cake_image);
		img_car = (ImageButton) findViewById(R.id.car_image);
		img_deco = (ImageButton) findViewById(R.id.deco_image);
		img_hotel = (ImageButton) findViewById(R.id.hotel_image);
		
		tv_name = (TextView) findViewById(R.id.welcome_text);
		
		/** TODO 1.1 SHARED PREFS (WELCOME + NAME) TEXTVIEW**/

		/** TODO 5 ONCLICK IMAGEBUTTON + EXTRAS + START_ACTIVITY_FOR_RESULT -> EventListActivity **/
		
	}
	
	
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		
		if (item.getItemId() == R.id.menu_calculate) {
			fragmentOpened=true;
			FrameLayout frame = new FrameLayout(this);
	        frame.setId(CONTENT_VIEW_ID);
	        setContentView(frame, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
	        
	        /** TODO 4.1 MENU ITEM ACTION - LOAD BillingFragment**/
	       
	       
		}
		return super.onOptionsItemSelected(item);
	}
	
	/** TODO 6 ON_ACTIVITY_RESULT -> TOAST **/

	
	@Override
	public void onBackPressed() {
			
			if(fragmentOpened==true){
				finish();
				startActivity(getIntent());
			}
			else
				finish();
			
	}
}
