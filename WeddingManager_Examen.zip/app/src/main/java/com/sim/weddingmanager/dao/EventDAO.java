package com.sim.weddingmanager.dao;


/** TODO 10.1 CREATE THE DAO **/

public class EventDAO{

}
